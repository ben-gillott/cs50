
#ifndef LUAUTF8_LUTF8LIB_H
#define LUAUTF8_LUTF8LIB_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lua.h"

LUALIB_API int luaopen_luautf8(lua_State *L);

#ifdef __cplusplus
}
#endif

#endif /* LOVE_LUAUTF8_LUTF8LIB_H */
